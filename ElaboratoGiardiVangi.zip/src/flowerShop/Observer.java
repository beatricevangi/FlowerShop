package flowerShop;

public interface Observer {
    void update(Object obj);
}
