package flowerShop;

public interface Menu {
    void show();
}
