public class Customer {
    private String email;
    private String address;
    private boolean logged;

    void createOrder(){
        //TODO
    }

    void myOrders(){
        //TODO
    }

    void login(){
        //TODO
    }
}
