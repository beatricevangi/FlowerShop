import java.util.ArrayList;

// TODO È UN SINGLETON
public class Catalog {
    private ArrayList<Product> c = new ArrayList<>();

    public void addToCatalog(){
        //TODO
    }

    public void displayCatalog(){
        //TODO
    }
}
