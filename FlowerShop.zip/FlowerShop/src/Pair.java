public class Pair<T1,T2>{
        public T1 first;
        public T2 second;
        public Pair(T1 a, T2 b) {
            first = a;
            second = b;
        }
    }

// https://java.yocker.com/29067/perche-non-possiamo-usare-i-puntatori-in-java.html#:~:text=Java%20non%20usa%20mai%20riferimenti,programmazione%20%C3%A8%20con%20i%20puntatori.