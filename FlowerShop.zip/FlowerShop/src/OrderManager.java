public class OrderManager {
    private OrderList ol = new OrderList();


    public void createOrder(){
        //TODO
    }

    public void completeOrder(){
        //TODO
    }

    public void deleteOrder(){
        //TODO
    }
}
