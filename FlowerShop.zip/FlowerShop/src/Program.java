// TODO È UN SINGLETON
public class Program {
    private OrderList ol = new OrderList();
    public static Program p = new Program();

    public void createOrderManager(){
        //TODO
    }

    public void createCustomer(){
        //TODO
    }

    public void viewCatalog(){
        //TODO
    }

    public void login(){
        //TODO
    }

    public static Program getInstance(){
        //TODO
        return p;
    }

    public void viewMyOrders(Customer c){
        //TODO
    }


}
