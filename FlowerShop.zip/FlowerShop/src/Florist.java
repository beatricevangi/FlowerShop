
public class Florist {
    public OrderList ol;
    public Order currentorder;
    public Storage s;
    public Catalog c;
    public ShippingCompany sc;

    public void createCatalog(){

    }

    public void createProduct(){

    }

    public void pickOrder(){

    }

    public void sendOrder(){

    }

    public void callShippingCompany(){

    }

    public void doOrder(){

    }

}
