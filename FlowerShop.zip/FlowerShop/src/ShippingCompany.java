public class ShippingCompany {
    private String name;

    void ship(){
        System.out.print("Ci pensa Bartolini!");
        // TODO mah qua anche niente però decidere visibilità
    }
}
